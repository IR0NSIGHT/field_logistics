class IRN {
  class general {
    file = "IRN\functions";
    class test {};
    class marker {};
    class cloneContainer {};
    class clearContainer {};
    class getDir {};
    class addCallAction {};
    class orderSupply {};
  };
};